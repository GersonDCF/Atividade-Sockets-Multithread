import java.net.*;
import java.io.*;
import java.util.*;

public class ServidorSocket {
    private ServerSocket servidor;
    private List<Cartao> cartoes;

    public ServidorSocket(int porta) throws IOException {
        servidor = new ServerSocket(porta);
        cartoes = new ArrayList<>();

        cartoes.add(new Cartao("401231021845", 1000.00)); // Cartão com número 4012-3102-1845 e saldo de 1000 reais
        cartoes.add(new Cartao("123456789012", 500.00));  // Cartão com número 1234-5678-9012 e saldo de 500 reais
        cartoes.add(new Cartao("987654321098", 2000.00)); // Cartão com número 9876-5432-1098 e saldo de 2000 reais
    }

    public void iniciar() throws IOException {
        while (true) {
            Socket cliente = servidor.accept();
            processarRequisicao(cliente);
        }
    }

    public synchronized void processarRequisicao(Socket cliente) throws IOException {
        InputStream entrada = cliente.getInputStream();
        OutputStream saida = cliente.getOutputStream();
        byte[] requisicao = new byte[1024];
        entrada.read(requisicao);
        // Ler a mensagem ISO 8583
        String tipoMensagem = new String(requisicao, 0, 4);
        String valorTransacao = new String(requisicao, 12, 4);
        String numeroCartao = new String(requisicao, 48, 12);
        // Verificar o saldo do cartão
        Cartao cartao = buscarCartao(numeroCartao);
        if (cartao == null) {
            // Cartão inexistente, resposta 05 e NSU retornado com zeros
            byte[] resposta = gerarResposta("05", "000000000000");
            saida.write(resposta);
        } else if (cartao.getSaldo() < Double.parseDouble(valorTransacao)) {
            // Saldo indisponível, resposta 51 e NSU retornado com zeros
            byte[] resposta = gerarResposta("51", "000000000000");
            saida.write(resposta);
        } else {
            // Transação executada, resposta 00 e NSU retornado (pode ser um auto incremento implementado em classe mesmo)
            cartao.setSaldo(cartao.getSaldo() - Double.parseDouble(valorTransacao));
            byte[] resposta = gerarResposta("00", "000000000001"); // Aqui você pode implementar um auto incremento para o NSU
            saida.write(resposta);
        }
    }

    public Cartao buscarCartao(String numeroCartao) {
        for (Cartao cartao : cartoes) {
            if (cartao.getNumero().equals(numeroCartao)) {
                return cartao;
            }
        }
        return null;
    }

    public byte[] gerarResposta(String codigoResposta, String nsu) {
        String resposta = "0210"; // Tipo da mensagem - 210 é uma mensagem de resposta para a transação
        resposta += "00000000002010"; // Bit 4, valor
        resposta += "104400"; // Bit 12, hora local da transacao
        resposta += "0512"; // Bit 13, data da transacao
        resposta += "040104"; // Bit 33, rede transmissora
        resposta += codigoResposta; // Bit 39, codigo de resposta
        resposta += nsu; // Bit 127, NSU destino
        return resposta.getBytes();
    }
}
