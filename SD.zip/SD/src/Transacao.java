public class Transacao {
    private Cartao cartao;
    private double valor;

    public Transacao(Cartao cartao, double valor) {
        this.cartao = cartao;
        this.valor = valor;
    }

    public Cartao getCartao() {
        return cartao;
    }

    public void setCartao(Cartao cartao) {
        this.cartao = cartao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
