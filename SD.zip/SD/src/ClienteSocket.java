import java.net.*;
import java.io.*;

public class ClienteSocket {
    private Socket cliente;

    public ClienteSocket(String host, int porta) throws IOException {
        cliente = new Socket(host, porta);
    }

    public void enviarRequisicao(byte[] requisicao) throws IOException {
        OutputStream saida = cliente.getOutputStream();
        saida.write(requisicao);
    }

    public byte[] receberResposta() throws IOException {
        InputStream entrada = cliente.getInputStream();
        byte[] resposta = new byte[1024];
        entrada.read(resposta);
        return resposta;
    }
}